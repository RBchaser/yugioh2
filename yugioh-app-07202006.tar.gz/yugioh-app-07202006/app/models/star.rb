class Star < ApplicationRecord
    has_many:statuses
end
