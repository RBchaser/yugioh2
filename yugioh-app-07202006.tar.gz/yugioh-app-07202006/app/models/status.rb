class Status < ApplicationRecord
    belongs_to:star
end
