module StarsHelper
end
